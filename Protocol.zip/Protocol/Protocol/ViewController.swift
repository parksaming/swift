//
//  ViewController.swift
//  Protocol
//
//  Created by tan comit on 3/5/20.
//  Copyright © 2020 Tan Truong. All rights reserved.
//

import UIKit

class ViewController: UIViewController,ChaneBackgroundProtocolDelegate {
    
    
    func Color(color: UIColor) {
        print("vao day")
    }
    
    @IBAction func fcfg(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyBoard.instantiateViewController(identifier: "viewColor") as ColorViewController
        vc.delegate = self;        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

