//
//  ColorViewController.swift
//  Protocol
//
//  Created by tan comit on 3/5/20.
//  Copyright © 2020 Tan Truong. All rights reserved.
//

import UIKit

protocol ChaneBackgroundProtocolDelegate {
    func Color(color:UIColor)
}

class ColorViewController: UIViewController {

    var delegate:ChaneBackgroundProtocolDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
   
    @IBAction func blueColor(_ sender: UIButton) {
        delegate?.Color(color: .blue)
    }
    
    @IBAction func redColor(_ sender: UIButton) {
        delegate?.Color(color: .red)
    }
    //khi click button doi mau view
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
